﻿#include <iostream>
#include <filesystem>
#include <string>
#include <fstream>
#include <windows.h>


using namespace std;


int main()
{
    const string FOLDER_NAME = "aplikacje_source";

    ofstream createFolderWithProjects;
    string createFolderWithProjectsCode, projectsLocalization;
    string currentPathStr3 = filesystem::current_path().string();

    createFolderWithProjects.open("createFolderWithProjectsPS.ps1");
    createFolderWithProjectsCode = "$a = Get-Variable HOME -valueOnly\n";
    createFolderWithProjectsCode += "$FolderName = '"+ FOLDER_NAME +"'\n";
    createFolderWithProjectsCode += "cd $a\n";
    createFolderWithProjectsCode += "if (-not (Test-Path $FolderName)) {New-Item $FolderName -ItemType Directory}\n";
    createFolderWithProjectsCode += "New-Item " + currentPathStr3 + "\\temp.txt\n";
    createFolderWithProjectsCode += "attrib +h "+ currentPathStr3 + "\\temp.txt\n";
    createFolderWithProjectsCode += "Set-Content " + currentPathStr3 + "\\temp.txt $a\n";
    createFolderWithProjects << createFolderWithProjectsCode << endl;
    createFolderWithProjects.close();
    system("powershell -ExecutionPolicy Bypass -F createFolderWithProjectsPS.ps1");
    system("CLS");
    remove("createFolderWithProjectsPS.ps1");

    ifstream tempText;
    tempText.open("temp.txt");
    tempText >> projectsLocalization;
    //cout << projectsLocalization;
    tempText.close();
    remove("temp.txt");
    string projectsLocalization1, projectsLocalization2;
    projectsLocalization1 = projectsLocalization + "/aplikacje_source/";
    string z;
    int zInt;
    bool i = true;
    
    if (!filesystem::exists(string(projectsLocalization1 + "config.txt"))) {
        //cout << string(projectsLocalization1 + "config.txt") << endl;
        int if2FA;
        string username, email, autenticate;
        cout << "Nie posiadam pliku z logowaniem, zaloguj sie." << endl;
        cout << "Podaj username: ";
        getline(cin >> ws, username);
        cout << "Podaj email: ";
        getline(cin >> ws, email);
        cout << "Posiadasz 2FA? (0 - nie, 1 - tak)\n >";
        cin >> if2FA;
        if (if2FA) {
            cout << "Podaje token (jesli nie wiesz jak go utworzyc to wypisz 0: ";
            getline(cin >> ws, autenticate);
            if (autenticate == "0") {
                cout << "To create a personal access token in GitHub, follow these steps:" << endl;
                cout << " 1. Log into the online administrative console." << endl;
                cout << " 2.Under your GitHub user profile(not the repository profile), click the “Settings” link." << endl;
                cout << " 3. Scroll down and click the “Developer Settings” link." << endl;
                cout << " 4. Click the GitHub “Personal access tokens” link." << endl;
                cout << " 5. Click the “Generate new token” link and provide your password again if required." << endl;
                cout << " 6. Provide a name for the GitHub personal access token in the “Note” field." << endl;
                cout << " 7. Set the access token’s expiration timeout to “No expiration.”" << endl;
                cout << " 8. Click the checkbox for every permission scope to give your GitHub token full repository access." << endl;
                cout << " 9. Click “Generate token.”" << endl;
                cout << " 10. Copy the GitHub Personal Access Token and pase it here\n> ";
                getline(cin >> ws, autenticate);
            }
        }
        else {
            cout << "Podaj haslo: ";
            getline(cin >> ws, autenticate);
        }

        ofstream file;
        string fileText;

        file.open("createloginfile.ps1");
        fileText = "New-Item " + projectsLocalization1 + "\\config.txt\n";
        fileText += "attrib +h " + projectsLocalization1 + "\\config.txt\n";
        fileText += "Set-Content " + projectsLocalization1 + "\\config.txt '" + to_string(if2FA) + "' \n";
        fileText += "Add-Content " + projectsLocalization1 + "\\config.txt '" + username + "'\n";
        fileText += "Add-Content " + projectsLocalization1 + "\\config.txt '" + email + "'\n";
        fileText += "Add-Content " + projectsLocalization1 + "\\config.txt '" + autenticate + "'\n";
        file << fileText << endl;
        file.close();
        system("powershell -ExecutionPolicy Bypass -F createloginfile.ps1");
        remove("createloginfile.ps1");
    }

    do {
        system("CLS");
        cout << "Co chcesz zrobic:\n - 1 - Nowy projekt z gita\n - 2 - Zzipowac istniejacy projekt\n - 3 - Usunac istniejacy projekt\n - 4 - Edytowac dane logowania\n - Inna liczba - koniec programu\n> ";
        cin >> z;
        system("CLS");
        zInt = stoi(z);

        switch (zInt)
        {
        case 1:
            if (true) {
                cout << "Upewnij sie ze masz zainstalowanego gita i vs code." << endl;
                fstream file;
                file.open(string(projectsLocalization1 + "config.txt"));
                int i = 0, if2FA;
                string username, email, autenticate;
                file >> if2FA;
                file >> username;
                file >> email;
                file >> autenticate;
                file.close();
                do {
                    string github, nazwa, icoLink;

                    cout << "Nazwij aplikacje\n> ";
                    getline(cin >> ws, nazwa);
                    projectsLocalization2 = projectsLocalization + "/aplikacje_source/" + nazwa + "/";
                    if (filesystem::is_directory(string(projectsLocalization1 + nazwa))) {
                        cout << "Istnieje juz projekt o takiej nazwie" << endl;
                    }
                    else {
                        cout << "Give github to clone\n> ";
                        cin >> github;
                        cout << "Podaj link bezwzgledny do pliku .ico, ktory bedzie ikonka tego projektu, lub wpisz 'bez' aby pozostawic z domyslna, podaj z \" przed i po linku, aby prawidlowo zaladowac ikone.\n> ";
                        cin >> icoLink;
                        filesystem::current_path(projectsLocalization1);
                        ofstream file, exefile, createShortcutFile;
                        string gitClone, inFile, createShortcut;

                        file.open("gitCloneFile.ps1");
                        gitClone = "mkdir \"" + nazwa + "\"\n";
                        gitClone += "cd \"" + nazwa + "\"\n";
                        gitClone += "git clone " + github + " \"" + nazwa + "\"\n";
                        gitClone += "cd \"" + nazwa + "\"\n";
                        gitClone += "git config --local user.name '" + username + "'\n";
                        gitClone += "git config --local user.email '" + email + "'\n";
                        if (if2FA) {
                            gitClone += "git config --local user.token '" + autenticate + "'\n";
                        }
                        else {
                            gitClone += "git config --local user.passowrd '" + autenticate + "'\n";
                        }


                        file << gitClone << endl;
                        file.close();
                        system("powershell -ExecutionPolicy Bypass -F gitCloneFile.ps1");
                        remove("gitCloneFile.ps1");

                        filesystem::current_path(projectsLocalization2);
                        exefile.open(nazwa + ".cmd");
                        inFile = "cd \"" + projectsLocalization2 + "\\" + nazwa + "\"\n";
                        inFile += "git pull\n";
                        inFile += "cd \"" + projectsLocalization2 + "\"\n";
                        inFile += "call code -w \"" + nazwa + "\"\n";
                        inFile += "cd \"" + projectsLocalization2 + "\\" + nazwa + "\"\n";
                        inFile += "git add .\n";
                        inFile += "git status\n";
                        inFile += "git commit -m \"Automatic commit\"\n";
                        inFile += "git push\n";

                        //inFile += "PAUSE";
                        exefile << inFile << endl;
                        exefile.close();

                        createShortcutFile.open("tempPS.ps1");
                        createShortcut = "$a = Get-Variable HOME -valueOnly\n";
                        createShortcut += "$ComObj = New-Object -ComObject WScript.Shell\n";
                        createShortcut += "$ShortCut = $ComObj.CreateShortcut($a + \"\\Desktop\\" + nazwa + ".lnk\")\n";
                        createShortcut += "$ShortCut.TargetPath = \"" + projectsLocalization2 + "\\" + nazwa + ".cmd\"\n";
                        createShortcut += "$ShortCut.Description = \"" + nazwa + " app\"\n";
                        createShortcut += "$ShortCut.WindowStyle = 7\n";
                        if (icoLink != "bez") {
                            createShortcut += "$ShortCut.IconLocation = " + icoLink + "\n";
                        }
                        createShortcut += "$ShortCut.Save()\n";
                        createShortcutFile << createShortcut << endl;
                        createShortcutFile.close();
                        system("powershell -ExecutionPolicy Bypass -F tempPS.ps1");
                        remove("tempPS.ps1");

                        filesystem::current_path(projectsLocalization1);

                        i = false;
                        cout << "Na pulpicie jest gotowe do otworzenia" << endl;
                    }
                } while (i);
                break;
            }
        case 2:
            if (1) {
                string nazwa, zipNazwa;
                ofstream listProjectsFile;
                string listProjects;
                cout << "Lista wszystkich projektow:" << endl;
                listProjectsFile.open("listProjectsFilePS.ps1");
                listProjects = "cd " + projectsLocalization1 + "\n";
                listProjects += "ls -Name\n";
                listProjectsFile << listProjects << endl;
                listProjectsFile.close();
                system("powershell -ExecutionPolicy Bypass -F listProjectsFilePS.ps1");
                remove("listProjectsFilePS.ps1");

                cout << "\nNazwa aplikacji\n> ";
                getline(cin >> ws, nazwa);
                cout << "Jak chcesz nazwac plik zip (jesli taki juz istnieje to go nadpisze)\n> ";
                getline(cin >> ws, zipNazwa);
                projectsLocalization2 = projectsLocalization + "/aplikacje_source/" + nazwa + "/";
                if (filesystem::is_directory(string(projectsLocalization1 + nazwa))) {
                    filesystem::current_path(projectsLocalization2);
                    ofstream zipFile;
                    string zipping;

                    zipFile.open("zippingFile.ps1");
                    zipping = "$a = Get-Variable HOME -valueOnly\n";
                    zipping += "Compress-Archive -Force -Path \"" + projectsLocalization2 + "\\" + nazwa + "\" -DestinationPath $a\"\\Desktop\\" + zipNazwa + ".zip\"\n";
                    zipFile << zipping << endl;
                    zipFile.close();
                    system("powershell -ExecutionPolicy Bypass -F zippingFile.ps1");
                    remove("zippingFile.ps1");
                    cout << "Folder zostal zzipowany i plik zip znajduje sie na pulpicie" << endl;
                }
                else {
                    cout << "Nie istnieje projekt o takiej nazwie" << endl;
                }
            }
            break;
        case 3:
            if (true) {
                ofstream listProjectsFile;
                string listProjects, nazwa;
                cout << "Lista wszystkich projektow:" << endl;
                listProjectsFile.open("listProjectsFilePS.ps1");
                listProjects = "cd " + projectsLocalization1 + "\n";
                listProjects += "ls -Name\n";
                listProjectsFile << listProjects << endl;
                listProjectsFile.close();
                system("powershell -ExecutionPolicy Bypass -F listProjectsFilePS.ps1");
                remove("listProjectsFilePS.ps1");
                cout << "Nazwa projektu, ktory chcesz usunac\n> ";
                getline(cin >> ws, nazwa);
                if (filesystem::is_directory(string(projectsLocalization1 + nazwa))) {
                    projectsLocalization2 = projectsLocalization + "/aplikacje_source/" + nazwa + "/";
                    filesystem::remove_all(projectsLocalization2);
                    filesystem::remove(projectsLocalization2);
                    cout << "Projekt usuniety pomyslnie. Skrot na pulpitu pozostal (nie dziala teraz), jesli chcesz go usunac, musisz zrobic to recznie." << endl;
                }
                else {
                    cout << "Projekt o takiej nazwie nie istnieje" << endl;
                }
                break;
            }
        case 4:
            if (true) {
                int coRobic;
                cout << "Co chcesz zmienic?\n 1 - Username\n 2 - Email\n 3 - Haslo / Token (Jesli masz 2FA)\n> ";
                cin >> coRobic;
                string username = "", email = "", autenticate = "";
                int if2FA=0;
                fstream file;
                file.open(string(projectsLocalization1 + "config.txt"));
                file >> if2FA;
                file >> username;
                file >> email;
                file >> autenticate;
                file.close();
                switch (coRobic) {
                case 1:
                    cout << "Aktualny username git-usera to " << username << endl;
                    cout << "Podaj nowy username\n> ";
                    cin >> username;
                    break;
                case 2:
                    cout << "Aktualny email git-usera to " << email << endl;
                    cout << "Podaj nowy email\n> ";
                    cin >> email;
                    break;
                case 3:
                    system("CLS");
                    cout << "Czy posiadasz 2FA?\n 0 - nie\n 1 - tak\n> ";
                    cin >> if2FA;
                    system("CLS");
                    if (if2FA) {
                        cout << "Podaj nowy token 2FA (Jesli nie wiesz jak dostac taki token to wypisz 0)\n> ";
                        cin >> autenticate;
                        system("CLS");
                        if (autenticate == "0") {
                            cout << "To create a personal access token in GitHub, follow these steps:" << endl;
                            cout << " 1. Log into the online administrative console." << endl;
                            cout << " 2.Under your GitHub user profile(not the repository profile), click the “Settings” link." << endl;
                            cout << " 3. Scroll down and click the “Developer Settings” link." << endl;
                            cout << " 4. Click the GitHub “Personal access tokens” link." << endl;
                            cout << " 5. Click the “Generate new token” link and provide your password again if required." << endl;
                            cout << " 6. Provide a name for the GitHub personal access token in the “Note” field." << endl;
                            cout << " 7. Set the access token’s expiration timeout to “No expiration.”" << endl;
                            cout << " 8. Click the checkbox for every permission scope to give your GitHub token full repository access." << endl;
                            cout << " 9. Click “Generate token.”" << endl;
                            cout << " 10. Copy the GitHub Personal Access Token and pase it here\n> ";
                            cin >> autenticate;
                        }
                    }
                    else {
                        cout << "Podaj nowe haslo\n> ";
                        cin >> autenticate;
                    }
                }
                ofstream file1;
                string fileText;

                file1.open("createloginfile.ps1");
                fileText += "attrib +h " + projectsLocalization1 + "\\config.txt\n";
                fileText += "Set-Content " + projectsLocalization1 + "\\config.txt '" + to_string(if2FA) + "' \n";
                fileText += "Add-Content " + projectsLocalization1 + "\\config.txt '" + username + "'\n";
                fileText += "Add-Content " + projectsLocalization1 + "\\config.txt '" + email + "'\n";
                fileText += "Add-Content " + projectsLocalization1 + "\\config.txt '" + autenticate + "'\n";
                file1 << fileText << endl;
                file1.close();
                system("powershell -ExecutionPolicy Bypass -F createloginfile.ps1");
                remove("createloginfile.ps1");
                break;
            }
        default:
            system("pause");
            return 0;
        }
    }while (true);
}
